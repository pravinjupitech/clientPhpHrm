export const Login = "/companyloginnew";
export const Save_location = "/save-location";
export const Pan_Verify = "/pancardvarified";
// export const Createcollection = "/attendence/create-collection";
export const Createcollection = "/api/createcollection";
export const Register = "/api/register";
export const Registervianode = "/attendence/register";
export const Recognizevianode = "/attendence/recongnition";
export const SaveData = "/api/recognize";
export const AttendanceList = "/api/attendanceAws";
export const Recognize = "/api/recognize";
export const ViewOneById = "/attendanceviewone";
export const SavedData = "/api/localDataAttendance";
export const Attendance = "/attendence/save-attendence";
export const HRM_ATTENDANCE_LIST =
  "https://node-second.rupioo.com/attendance-calculate/"; ///DATABASE

// hrm userlist
export const All_Users_HRM = "/user/user-list-hrm/";
export const RegisteredAttendanceUser = "/attendence/attendance-list/";
export const logsData = "/localDataAttendance";
export const logsdeleteData = "/attendancedelete";

export const RegisteredUser = "/attendancelist";
