import React from 'react'
import Login from '../components/Loginform'

function login() {
  return (
    <div>
      <Login/>
    </div>
  )
}

export default login
